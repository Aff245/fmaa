#!/usr/bin/env bash
set -e

rm -rf unzipped
echo "🧹 Folder 'unzipped/' berhasil dihapus!"
