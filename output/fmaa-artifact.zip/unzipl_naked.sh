#!/usr/bin/env bash
set -e

ZIPFILE="$1"
TEMP="__temp_unzipped"
LOG="unzipl_naked.log"

[[ -z "$ZIPFILE" ]] && echo "❌ Nama ZIP belum dikasih!" && exit 1
[[ ! -f "$ZIPFILE" ]] && echo "❌ File ZIP '$ZIPFILE' gak ditemukan!" && exit 1

echo "📦 Ekstrak ZIP ke folder sementara: $TEMP" | tee "$LOG"
rm -rf "$TEMP"
mkdir -p "$TEMP"
unzip -qq "$ZIPFILE" -d "$TEMP" >> "$LOG"

echo "📂 Scan semua file di dalam ZIP..." | tee -a "$LOG"
FILES=$(find "$TEMP" -type f)

if [[ -z "$FILES" ]]; then
  echo "❌ Tidak ada file dalam ZIP!" | tee -a "$LOG"
  rm -rf "$TEMP"
  exit 1
fi

echo "🚚 Pindahkan isi ZIP ke root repo..." | tee -a "$LOG"
for f in $FILES; do
  RELATIVE=$(basename "$f")
  cp -n "$f" "./$RELATIVE"
  echo "✅ Moved: $RELATIVE" >> "$LOG"
done

echo "🧹 Bersihin folder sementara..." | tee -a "$LOG"
rm -rf "$TEMP"

echo "✅ Selesai! Semua isi ZIP sudah ada di root" | tee -a "$LOG"
