#!/usr/bin/env bash
set -e

ZIPFILE="$1"
TARGETDIR="unzipped"

# Validasi input
[[ -z "$ZIPFILE" ]] && echo "⚠️ Harap masukkan nama file zip!" && exit 1
[[ ! -f "$ZIPFILE" ]] && echo "❌ File '$ZIPFILE' tidak ditemukan!" && exit 1

# Ekstraksi
mkdir -p "$TARGETDIR"
unzip -o "$ZIPFILE" -d "$TARGETDIR"
echo "✅ Selesai diekstrak ke: $TARGETDIR"
