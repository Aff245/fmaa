#!/bin/bash

ZIP_NAME="lnkpp-Toolkit-v1.zip"
EXCLUDES=".git .github $ZIP_NAME"
FILES=$(find . -mindepth 1 -maxdepth 1 | grep -vE "$(echo $EXCLUDES | sed 's/ /|/g')")

# Splash buat mood 🌈
touch splash_🎉.txt

# Validasi isi sebelum zip
if [ -z "$FILES" ]; then
  echo "❌ Tidak ada file yang bisa di-zip!"
  exit 1
fi

echo "📦 Memulai zip builder untuk lnkpp..."
zip -r "$ZIP_NAME" $FILES
echo "✅ ZIP selesai: $ZIP_NAME"
