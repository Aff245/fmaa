#!/bin/bash

REPO_DIR="."
OUTPUT_ZIP="repo_archive.zip"
EXCLUDE_DIR=".github/workflows"

# Check if the exclude directory exists
if [ ! -d "$EXCLUDE_DIR" ]; then
    echo "Warning: Exclude directory '$EXCLUDE_DIR' not found. Proceeding without exclusion."
fi

# Create the zip archive, excluding the specified directory
zip -r "$OUTPUT_ZIP" "$REPO_DIR" -x "$EXCLUDE_DIR/*" -x "$EXCLUDE_DIR/.*" -x "*.git/*" -x "*.git/.*"

if [ $? -eq 0 ]; then
    echo "Successfully created $OUTPUT_ZIP, excluding $EXCLUDE_DIR"
else
    echo "Error: Failed to create the zip archive."
    exit 1
fi


