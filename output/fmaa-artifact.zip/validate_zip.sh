#!/data/data/com.termux/files/usr/bin/bash

ZIP_FILE="$1"

if [[ ! -f "$ZIP_FILE" ]]; then
  echo "❌ ZIP file tidak ditemukan"
  exit 1
fi

if unzip -t "$ZIP_FILE" >/dev/null; then
  echo "✅ ZIP file valid dan bisa di-unzip"
else
  echo "❌ ZIP file corrupt atau tidak valid"
  exit 2
fi
