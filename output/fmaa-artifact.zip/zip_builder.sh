#!/bin/bash

# === zip_builder.sh: Toolkit Anti-blehh ===
ZIP_NAME="FarasToolkit-v1.zip"
EXCLUDES=".git .github $ZIP_NAME"
FILES=$(find . -mindepth 1 -maxdepth 1 | grep -vE "$(echo $EXCLUDES | sed 's/ /|/g')")

# Validasi isi sebelum zip
if [ -z "$FILES" ]; then
  echo "❌ Tidak ada file valid untuk di-ZIP!"
  exit 1
fi

# Tambahkan splash marker opsional
touch splash_🎉.txt

# Eksekusi zip
zip -r "$ZIP_NAME" $FILES
echo "✅ ZIP berhasil dibuat: $ZIP_NAME"
