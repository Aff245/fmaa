#!/usr/bin/env bash
set -e

echo "📁 Salin skrip ke folder scripts/"
mkdir -p scripts
cp validate_zip.sh unzipl_naked.sh select_zip.sh scripts/

echo "📝 Buat workflow GitHub Actions…"
mkdir -p .github/workflows
cp unzip_toolkit.yml .github/workflows/

echo "🔧 Atur hak akses executable pada skrip"
chmod +x scripts/*.sh tools/installer.sh

echo "✅ Toolkit terpasang! Jalankan 'bash scripts/select_zip.sh' atau trigger workflow."
