#!/usr/bin/env bash
set -e

ZIPFILE="$1"
TEMP="temp_flat"
LOG="unzipl_flat.log"

[[ -z "$ZIPFILE" ]] && echo "❌ Masukkan nama file ZIP!" && exit 1
[[ ! -f "$ZIPFILE" ]] && echo "❌ File '$ZIPFILE' gak ketemu!" && exit 1

echo "📦 Ekstrak '$ZIPFILE' ke folder sementara..." | tee "$LOG"
rm -rf "$TEMP"
mkdir -p "$TEMP"
unzip -o "$ZIPFILE" -d "$TEMP" >> "$LOG"

# Cari semua file di lapisan terdalam
DEEPEST=$(find "$TEMP" -type f)
if [[ -z "$DEEPEST" ]]; then
  echo "❌ Gagal: ZIP kosong atau file gak ditemukan!" | tee -a "$LOG"
  exit 1
fi

echo "📂 File ditemukan, memindahkan ke root..." | tee -a "$LOG"
find "$TEMP" -type f -exec mv -n {} . \;

# Cleanup
rm -rf "$TEMP"
echo "✅ Selesai! Semua file dari ZIP sekarang ada di root repo." | tee -a "$LOG"
