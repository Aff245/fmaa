#!/data/data/com.termux/files/usr/bin/bash

REPO_NAME="FarasToolkit"
ZIP_NAME="FarasToolkit-v1.zip"
ZIP_PATH="output/$ZIP_NAME"

echo "🔄 Pull dulu dari GitHub..."
git pull

echo "📦 ZIP semua isi repo..."
mkdir -p output
EXCLUDE=".git|output|scripts|$ZIP_NAME"
FILES=$(find . -mindepth 1 -maxdepth 1 | grep -vE "$EXCLUDE")

if [ -z "$FILES" ]; then
  echo "⚠️ Tidak ada file valid buat di-ZIP"
  exit 1
fi

zip -r "$ZIP_PATH" $FILES
echo "✅ ZIP selesai: $ZIP_PATH"
unzip -l "$ZIP_PATH"

echo "📤 Add + Commit hasil ZIP..."
git add "$ZIP_PATH"
git commit -m "Add auto-ZIP builder artifact"
git push origin main

echo "🚀 ZIP berhasil dipush ke GitHub!"
