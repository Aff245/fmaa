#!/usr/bin/env bash
set -e

ZIPFILE="$1"
TEMP="__temp_unzip"
LOGFILE="unzipl_flat.log"

[[ -z "$ZIPFILE" ]] && echo "❌ Masukkan file ZIP-nya!" && exit 1
[[ ! -f "$ZIPFILE" ]] && echo "❌ File '$ZIPFILE' tidak ditemukan!" && exit 1

echo "📦 Mengekstrak '$ZIPFILE' ke folder sementara..." | tee "$LOGFILE"
mkdir -p "$TEMP"
unzip -o "$ZIPFILE" -d "$TEMP" >> "$LOGFILE"

# 🕵️‍♂️ Cari folder terdalam (3 lapis ke dalam)
DEEPEST=$(find "$TEMP" -type d -print | sort | tail -n 1)

echo "🔎 Folder terdalam: $DEEPEST" | tee -a "$LOGFILE"

# 🚛 Pindahkan isi folder terdalam ke root
mv "$DEEPEST"/* . 2>/dev/null || echo "⚠️ Folder kosong atau gagal move" | tee -a "$LOGFILE"

# 🧹 Cleanup
rm -rf "$TEMP"
echo "✅ Selesai! Isi ZIP sekarang langsung di root." | tee -a "$LOGFILE"
