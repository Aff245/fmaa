#!/usr/bin/env bash
set -e

ZIPNAME="toolkit.zip"
EXCLUDES=(".git" ".github" "$ZIPNAME")

echo "📦 Membuat ZIP: $ZIPNAME"

# Bangun list file/folder yang mau di-zip
INCLUDES=$(find . -mindepth 1 -maxdepth 1 \
  ! -name "${EXCLUDES[0]}" \
  ! -name "${EXCLUDES[1]}" \
  ! -name "${EXCLUDES[2]}")

# Jalankan zip
zip -r "$ZIPNAME" $INCLUDES

echo "✅ ZIP selesai: $ZIPNAME"
