#!/data/data/com.termux/files/usr/bin/bash

ZIP_FILE="$1"
TARGET_DIR="unzipped/$(basename "$ZIP_FILE" .zip)"
LOG="log_summary.json"

mkdir -p "$TARGET_DIR"
unzip -o "$ZIP_FILE" -d "$TARGET_DIR"

# Log isi file
find "$TARGET_DIR" -type f > "$LOG"
echo "Unzip complete. Files logged to $LOG"

# Trigger perubahan
touch "$TARGET_DIR/.trigger_$(date +%s)"

# Git push
git config user.name "github-actions"
git config user.email "actions@github.com"
git add "$TARGET_DIR" "$LOG"
git commit -m "🔄 Auto-push hasil unzip dari $ZIP_FILE" || echo "⏩ Tidak ada perubahan"
git push origin HEAD
