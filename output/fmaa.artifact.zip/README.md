# Faras-Unzip-Core 🧠

Toolkit modular untuk unzip file .zip di Termux/PRoot:
- Validasi zip sebelum unzip
- Logging isi file
- Trigger perubahan otomatis
- Auto-push ke GitHub repo aman

## Usage
```bash
bash validate_zip.sh file.zip
bash unzip_and_push.sh file.zip
