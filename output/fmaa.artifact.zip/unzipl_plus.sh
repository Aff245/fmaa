#!/usr/bin/env bash
set -e

ZIPFILE="$1"
TEMP="temp_unzip"
LOGFILE="unzipl.log"

[[ -z "$ZIPFILE" ]] && echo "❌ Masukkan file ZIP-nya!" && exit 1
[[ ! -f "$ZIPFILE" ]] && echo "❌ File '$ZIPFILE' tidak ditemukan!" && exit 1

mkdir -p "$TEMP"
unzip -o "$ZIPFILE" -d "$TEMP" >> "$LOGFILE"

# Scan isi folder 2 lapis dan pindahkan semua ke root
DEEPEST=$(find "$TEMP" -type f | head -n 1)
DEEPPATH=$(dirname "$DEEPEST")
echo "📦 Memindahkan isi dari: $DEEPPATH" | tee -a "$LOGFILE"
mv "$DEEPPATH"/* . || true

# Cleanup
rm -rf "$TEMP"
echo "✅ Selesai! Semua isi ZIP sekarang di root folder." | tee -a "$LOGFILE"
